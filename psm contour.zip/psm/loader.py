"""
loader.py — наполнение справочников контура.

Идемпотентно: повторный запуск обновляет запись по коду заказчика, дублей не создаёт.
Загрузка не падает на грязных данных — всё, что не разобралось, попадает в отчёт
с указанием строки источника. На входе живые файлы подрядчика, а не выверенный обмен.

Порядок обязателен, каждый следующий шаг ссылается на предыдущие:
    единицы и синонимы → группы МТР → номенклатура (сначала группы) → характеристики.
"""

from __future__ import annotations

import json
import pathlib
from collections import OrderedDict
from datetime import datetime

import openpyxl
from sqlalchemy.orm import Session

from .core import (
    Characteristic, LoadRun, MtrGroup, Nomenclature, Origin, Uom, UomAlias,
)

FIXTURES = pathlib.Path(__file__).resolve().parent / "fixtures"


class Report:
    def __init__(self, run: LoadRun | None = None):
        self.run = run
        self.stats: OrderedDict[str, int] = OrderedDict()
        self.issues: list[dict] = []

    def add(self, key: str, n: int = 1) -> None:
        if n:
            self.stats[key] = self.stats.get(key, 0) + n

    def issue(self, level: str, where: str, message: str, row: int | None = None) -> None:
        self.issues.append({"level": level, "where": where, "message": message, "row": row})

    def to_run(self) -> None:
        if self.run is not None:
            self.run.stats_json = json.dumps(self.stats, ensure_ascii=False)
            self.run.issues_json = json.dumps(self.issues[:2000], ensure_ascii=False)
            self.run.finished_at = datetime.utcnow()


def start_run(db: Session, source_file: str, user_id: str | None = None) -> LoadRun:
    run = LoadRun(source_file=source_file, started_by_user_id=user_id)
    db.add(run)
    db.flush()
    return run


# ------------------------------ единицы ------------------------------

def load_uoms(db: Session, rep: Report) -> dict[str, Uom]:
    data = json.loads((FIXTURES / "uom_aliases.json").read_text(encoding="utf-8"))
    by_code: dict[str, Uom] = {u.code: u for u in db.query(Uom).all()}
    for u in data["base"]:
        obj = by_code.get(u["code"])
        if obj is None:
            obj = Uom(code=u["code"], name=u["name"], okei=u["okei"],
                      factor=u["factor"], origin=Origin.TAKT, predefined=True)
            db.add(obj)
            rep.add("Единицы измерения")
        else:
            obj.name, obj.okei, obj.factor = u["name"], u["okei"], u["factor"]
        by_code[u["code"]] = obj
    db.flush()
    for u in data["base"]:
        by_code[u["code"]].base_id = by_code[u["base"]].id
    known = {a.alias for a in db.query(UomAlias).all()}
    for alias, code in data["aliases"].items():
        if alias not in known:
            db.add(UomAlias(alias=alias, uom_id=by_code[code].id))
            rep.add("Синонимы единиц")
    db.flush()
    return by_code


def uom_resolver(db: Session):
    """Возвращает функцию «написание → Uom». Неизвестное написание не молчит."""
    by_code = {u.code: u for u in db.query(Uom).all()}
    by_alias = {a.alias.strip().lower(): a.uom_id for a in db.query(UomAlias).all()}
    by_id = {u.id: u for u in by_code.values()}

    def resolve(raw) -> tuple[Uom | None, str | None]:
        s = str(raw or "").strip()
        if not s:
            return None, None
        if s in by_code:
            return by_code[s], None
        uid = by_alias.get(s.lower())
        if uid:
            return by_id[uid], None
        return None, s          # вернули исходное написание как проблему

    return resolve


# ------------------------------ группы МТР ------------------------------

def load_mtr_groups(db: Session, path: str, rep: Report, sheet: str = "Лист1") -> None:
    """Классификатор ресурсной ведомости: группа, тип, ответственный."""
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    if sheet not in wb.sheetnames:
        rep.issue("error", "Группы МТР", f"лист «{sheet}» не найден")
        wb.close()
        return
    seen: dict[str, MtrGroup] = {}
    idx = 0
    for r, row in enumerate(wb[sheet].iter_rows(min_row=2, max_col=3, values_only=True), 2):
        if not row[0] or not row[1]:
            continue
        gname = str(row[0]).replace("_", " ").strip()
        key = gname.upper()
        if key not in seen:
            idx += 1
            code = f"G-{idx:03d}"
            grp = (db.query(MtrGroup).filter(MtrGroup.external_code == code).one_or_none()
                   or MtrGroup(external_code=code, is_folder=True, origin=Origin.CUSTOMER))
            grp.name = gname
            db.add(grp)
            db.flush()
            seen[key] = grp
            rep.add("Группы МТР")
        tname = str(row[1]).strip()
        tcode = f"{seen[key].external_code}.{abs(hash(tname)) % 10**6:06d}"
        obj = (db.query(MtrGroup)
                 .filter(MtrGroup.parent_id == seen[key].id, MtrGroup.name == tname)
                 .one_or_none())
        if obj is None:
            db.add(MtrGroup(external_code=tcode, name=tname, parent_id=seen[key].id,
                            responsible=str(row[2] or "") or None, origin=Origin.CUSTOMER))
            rep.add("Типы МТР")
        else:
            obj.responsible = str(row[2] or "") or None
    db.flush()
    wb.close()


# ------------------------------ номенклатура ------------------------------

def load_nomenclature(db: Session, path: str, rep: Report, sheet: str = "список") -> None:
    """Приложение №3, лист «список».

    Колонка A — признак ЭтоГруппа. Родитель элемента — ближайшая группа выше по списку:
    иерархия между самими группами в выгрузке заказчика не сохранена, все группы
    встают в корень.
    """
    resolve = uom_resolver(db)
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    if sheet not in wb.sheetnames:
        rep.issue("error", "Номенклатура", f"лист «{sheet}» не найден")
        wb.close()
        return

    cache: dict[str, Nomenclature] = {
        n.external_code: n for n in db.query(Nomenclature).filter(Nomenclature.external_code.isnot(None))
    }
    seen_char: set[tuple[str, str]] = set()
    parent: Nomenclature | None = None
    bad_uom: dict[str, int] = {}

    for r, row in enumerate(wb[sheet].iter_rows(min_row=5, max_col=7, values_only=True), 5):
        flag = str(row[0] or "").strip()
        code = str(row[1] or "").strip()
        if not code:
            continue
        name = str(row[2] or "").strip()
        is_folder = (flag == "Да")

        obj = cache.get(code)
        if obj is None:
            obj = Nomenclature(external_code=code, name=name, is_folder=is_folder,
                               origin=Origin.CUSTOMER,
                               parent_id=None if is_folder else (parent.id if parent else None))
            db.add(obj)
            db.flush()
            cache[code] = obj
            rep.add("Группы номенклатуры" if is_folder else "Позиции номенклатуры")
        else:
            obj.name = name
            obj.touch()
        if is_folder:
            parent = obj
            continue

        ccode = str(row[3] or "").strip()
        if not ccode:
            rep.add("Позиции без характеристик")
            continue
        if (code, ccode) in seen_char:
            rep.issue("warning", "Характеристики", f"{ccode}: повтор внутри {code}", r)
            continue
        seen_char.add((code, ccode))

        uom, bad = resolve(row[5])
        if bad:
            bad_uom[bad] = bad_uom.get(bad, 0) + 1

        ch = (db.query(Characteristic)
                .filter(Characteristic.owner_id == obj.id,
                        Characteristic.external_code == ccode).one_or_none())
        cname = str(row[4] or "").strip()
        if ch is None:
            db.add(Characteristic(external_code=ccode, name=cname, owner_id=obj.id,
                                  uom_id=uom.id if uom else None, origin=Origin.CUSTOMER))
            rep.add("Характеристики")
        else:
            ch.name = cname
            ch.uom_id = uom.id if uom else None
            ch.touch()
        if len(seen_char) % 5000 == 0:
            db.flush()

    db.flush()
    wb.close()
    for raw, cnt in sorted(bad_uom.items(), key=lambda x: -x[1]):
        rep.issue("warning", "Единицы измерения",
                  f"написание «{raw}» вне классификатора, встретилось {cnt} раз")
    rep.add("Единиц вне классификатора", len(bad_uom))
