"""
conftest.py — общая обвязка тестов контура.

Тестовая база отдельная и всегда одноразовая. Рабочий DATABASE_URL здесь не используется
намеренно: прогон тестов на нём затрёт данные. Схема создаётся только из PsmBase.metadata,
кадровые таблицы ТАКТ в неё не попадают вообще.
"""

from __future__ import annotations

import json
import os
import pathlib
import sys

import pytest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))

FIXTURES = pathlib.Path(__file__).resolve().parents[1] / "fixtures"


@pytest.fixture(scope="session")
def golden():
    return json.loads((FIXTURES / "golden_kj1.json").read_text(encoding="utf-8"))["cases"]


@pytest.fixture(scope="session")
def uom_fixture():
    return json.loads((FIXTURES / "uom_aliases.json").read_text(encoding="utf-8"))


@pytest.fixture()
def db(tmp_path):
    """Пустая база на файл теста. Разрушается вместе с tmp_path."""
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from psm.core import PsmBase
    import psm.access  # noqa: F401  — регистрирует psm_user_role в метадате

    os.environ.pop("DATABASE_URL", None)          # схема psm только на PostgreSQL
    engine = create_engine(f"sqlite:///{tmp_path/'test.db'}")
    PsmBase.metadata.create_all(engine)
    session = sessionmaker(bind=engine)()
    try:
        yield session
    finally:
        session.close()


@pytest.fixture(scope="session")
def corpus():
    """Кандидаты для сопоставителя.

    По умолчанию — небольшой набор, повторяющий неоднозначности реального справочника:
    три дубля бетона и два ГОСТа на А240. Если задан PSM_CORPUS_DB, тянем полный
    справочник из него и тест становится честной регрессией на 141 776 позициях.
    """
    path = os.getenv("PSM_CORPUS_DB")
    if path and pathlib.Path(path).exists():
        import sqlite3
        con = sqlite3.connect(path)
        rows = con.execute(
            "SELECT ch.code, n.name, ch.name FROM psm_characteristic ch "
            "JOIN psm_nomenclature n ON n.code = ch.nom_code").fetchall()
        con.close()
        return rows
    return [
        ("МЦ0127884", "Арматура, т", "12 А500СЕ, ГОСТ 34028-2016"),
        ("МЦ0130733", "Арматура, т", "8 А500СЕ ГОСТ 34028-2016"),
        ("МЦ0130734", "Арматура, т", "10 А500СЕ ГОСТ 34028-2016"),
        ("МЦ0130735", "Арматура, т", "16 А500СЕ ГОСТ 34028-2016"),
        ("МЦ0130736", "Арматура, т", "22 А500СЕ ГОСТ 34028-2016"),
        ("МЦ0112090", "Арматура, т", "6 А240 ГОСТ 34028-2016"),
        ("МЦ0112126", "Арматура, т", "6 А240 ГОСТ 5781-82"),
        ("МЦ0071555", "Арматура, т", "8 А240 ГОСТ 34028-2016"),
        ("МЦ0069814", "Арматура, т", "8-А240 ГОСТ 34028-2016"),
        ("МЦ0088031", "Сетка арматурная сварная", "Ф6 А240 100х100 мм ГОСТ 34028-2016"),
        ("МЦ0115519", "Бетон", "В25 F300 W8"),
        ("МЦ0127898", "Бетон", "В25, W8, F300, ГОСТ 26633-2015"),
        ("МЦ0131887", "Бетон", "В25 F300 W8 ГОСТ 26633-2015"),
        ("МЦ0130727", "Труба, т", "159х4,5, С255, ГОСТ 10704-91"),
        ("000007710", "Труба, т", "159х4,5 Ст20 ГОСТ 8732-78"),
        ("000017474", "Труба, т", "530х5 В Ст3пс4 ГОСТ 10704-91"),
        ("МЦ0112006", "Уплотнитель", "бентонитовый шнур ТУ-5774-002-38397632-2015"),
        ("000000150", "Провод медный", "РГКМ 6"),
    ]
