"""Загрузка: идемпотентность и разбор единиц.

Второй прогон обязан дать те же счётчики. Это единственная защита от тихого
задвоения справочника при повторной выгрузке от заказчика.
"""

import pytest

from psm.core import Uom, UomAlias, Nomenclature, Characteristic


def _seed_uoms(db, fixture):
    for u in fixture["base"]:
        db.add(Uom(code=u["code"], name=u["name"], okei=u["okei"], factor=u["factor"]))
    db.flush()
    by_code = {u.code: u for u in db.query(Uom).all()}
    for u in fixture["base"]:
        by_code[u["code"]].base_id = by_code[u["base"]].id
    for alias, code in fixture["aliases"].items():
        db.add(UomAlias(alias=alias, uom_id=by_code[code].id))
    db.flush()
    return by_code


def test_uom_conversion_to_base(db, uom_fixture):
    by_code = _seed_uoms(db, uom_fixture)
    assert by_code["т"].to_base(1) == 1000          # тонна в килограммы
    assert by_code["кг"].to_base(41.8919) == 41.8919


def test_aliases_resolve(db, uom_fixture):
    by_code = _seed_uoms(db, uom_fixture)
    alias = {a.alias: a.uom_id for a in db.query(UomAlias).all()}
    assert alias["тн"] == by_code["т"].id
    assert alias["к-т"] == by_code["компл"].id
    assert alias["м³"] == by_code["м3"].id


def test_load_is_idempotent(db):
    """Повторная загрузка обновляет запись по коду заказчика, а не создаёт вторую."""
    def upsert(code, name):
        obj = (db.query(Nomenclature)
                 .filter(Nomenclature.external_code == code).one_or_none())
        if obj is None:
            obj = Nomenclature(external_code=code, name=name)
            db.add(obj)
        else:
            obj.name = name
        db.flush()
        return obj

    upsert("00000000401", "Арматура, т")
    upsert("00000000421", "Бетон")
    first = db.query(Nomenclature).count()

    upsert("00000000401", "Арматура, т")
    upsert("00000000421", "Бетон")
    assert db.query(Nomenclature).count() == first == 2


def test_characteristic_code_unique_within_owner(db):
    owner = Nomenclature(external_code="00000000401", name="Арматура, т")
    db.add(owner)
    db.flush()
    db.add(Characteristic(external_code="МЦ0127884", name="12 А500СЕ", owner_id=owner.id))
    db.flush()
    db.add(Characteristic(external_code="МЦ0127884", name="дубль", owner_id=owner.id))
    with pytest.raises(Exception):
        db.flush()


def test_position_without_customer_code_is_marked(db):
    """Труба 478х5, МН117-6, ДБ1 и ДБ2 заводятся у нас и в 1С не уходят."""
    owner = Nomenclature(external_code="00000000384", name="Труба, т")
    db.add(owner)
    db.flush()
    ch = Characteristic(name="478х5 С255-5", owner_id=owner.id,
                        external_code=None, needs_code=True)
    db.add(ch)
    db.flush()
    assert ch.external_code is None and ch.needs_code is True
