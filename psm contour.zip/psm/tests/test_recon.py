"""Сверка комплекта: РД против регистра комплектации.

Числа взяты из разбора 0220-4957-12-83-КЖ1 изм.4 и регистра СВК изм.0. Тест сторожит
не сами цифры, а способ их получения: расхождение должно считаться запросом и иметь
допуск, а не сверяться глазами.
"""

import pytest

TOLERANCE = 0.001          # 0,1%

VOR_KJ1 = {
    "бетон, м3": 367.720,
    "арматура, т": 41.8919,
    "гильзы, кг": 77.96,
    "закладные ДБ1/ДБ2, шт": 9,
    "МН117-6, шт": 12,
    "шнур, пог. м": 92.8,
}
SVK_KJ1 = {
    "бетон, м3": 244.914,
    "арматура, т": 18.724,
    "гильзы, кг": 0,
    "закладные ДБ1/ДБ2, шт": 0,
    "МН117-6, шт": 12,
    "шнур, пог. м": 94.656,
}


def diff(a: float, b: float) -> float:
    return round(a - b, 4)


def status(vor: float, svk: float) -> str:
    if abs(vor - svk) <= TOLERANCE * max(abs(vor), 1):
        return "сходится"
    return "недобор" if vor > svk else "избыток"


@pytest.mark.parametrize("key", list(VOR_KJ1))
def test_every_position_has_verdict(key):
    assert status(VOR_KJ1[key], SVK_KJ1[key]) in ("сходится", "недобор", "избыток")


def test_concrete_gap_is_the_known_one():
    """122,806 м3 — ровно объём конструкций, добавленных изменением 4."""
    assert diff(VOR_KJ1["бетон, м3"], SVK_KJ1["бетон, м3"]) == 122.806
    assert status(VOR_KJ1["бетон, м3"], SVK_KJ1["бетон, м3"]) == "недобор"


def test_rebar_gap():
    assert diff(VOR_KJ1["арматура, т"], SVK_KJ1["арматура, т"]) == 23.1679


def test_embedded_parts_match():
    assert status(VOR_KJ1["МН117-6, шт"], SVK_KJ1["МН117-6, шт"]) == "сходится"


def test_cord_is_surplus():
    """Шнура в комплектации больше, чем в РД — это тоже расхождение, не «ничего страшного»."""
    assert status(VOR_KJ1["шнур, пог. м"], SVK_KJ1["шнур, пог. м"]) == "избыток"


def test_any_gap_blocks_protocol():
    """Правило приёмки: комплект с расхождением не выпускается в протокол."""
    verdicts = {k: status(VOR_KJ1[k], SVK_KJ1[k]) for k in VOR_KJ1}
    blocked = [k for k, v in verdicts.items() if v != "сходится"]
    assert blocked, "если расхождений нет — правило проверять не на чем"
    assert len(blocked) == 5
