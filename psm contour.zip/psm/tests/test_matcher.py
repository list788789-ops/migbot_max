"""Золотая выборка. Ворота релиза: ни одного ложного автосопоставления.

Цена ошибки здесь выше цены пропуска: неверный код тихо уходит в ЛРВ и всплывает
через месяц, пропуск же виден оператору сразу.
"""

import pytest

from psm.matcher import Matcher


@pytest.fixture(scope="module")
def matcher(corpus):
    return Matcher(corpus)


def _mode(how: str) -> str:
    if how in ("exact", "domain", "token"):
        return "auto"
    return "review" if how == "review" else "none"


def test_no_false_auto(matcher, golden):
    """Главный тест. Падение здесь останавливает сборку."""
    wrong = []
    for case in golden:
        code, score, how = matcher.match(case["query"])
        if _mode(how) != "auto":
            continue
        if case["mode"] != "auto" or (case["code"] and code != case["code"]):
            wrong.append((case["query"], case.get("code"), code, round(score, 2)))
    assert not wrong, f"ложные автосопоставления: {wrong}"


@pytest.mark.parametrize("idx", range(13))
def test_expected_mode(matcher, golden, idx):
    case = golden[idx]
    code, _, how = matcher.match(case["query"])
    assert _mode(how) == case["mode"], f"{case['query']}: ждали {case['mode']}, получили {how}"
    if case["mode"] == "auto" and case["code"]:
        assert code == case["code"]


def test_ambiguous_key_never_auto(matcher):
    """Доменный ключ с несколькими кандидатами уходит оператору.

    ARM|6|А240 находит и «Арматура 6 А240», и «Сетка арматурная сварная Ф6 А240».
    """
    _, _, how = matcher.match("Арматура 6 А240")
    assert how == "review"


def test_absent_position_returns_none(matcher):
    code, _, how = matcher.match("МН117-6")
    assert code is None and how == "none"
