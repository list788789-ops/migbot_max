"""Права контура. ПТО работает со справочниками и подтверждает сопоставления,
но не запускает загрузку и не видит ничего из кадрового контура."""

import pytest

from psm.access import AccessDenied, Perm, PsmRole, PsmUserRole, can, require, role_of


def test_pto_can_confirm_match():
    assert can(PsmRole.PTO, Perm.CONFIRM_MATCH)


def test_pto_cannot_run_load():
    assert not can(PsmRole.PTO, Perm.RUN_LOAD)
    with pytest.raises(AccessDenied):
        require(PsmRole.PTO, Perm.RUN_LOAD)


def test_pto_cannot_export():
    assert not can(PsmRole.PTO, Perm.RUN_EXPORT)


def test_admin_has_everything_pto_has():
    assert set(p for p in Perm if can(PsmRole.PTO, p)) <= set(p for p in Perm if can(PsmRole.ADMIN, p))


def test_no_role_is_denied():
    with pytest.raises(AccessDenied):
        require(None, Perm.VIEW_CATALOGS)


def test_role_read_from_own_table(db):
    """Роль ПСМ живёт в своей таблице и не зависит от UserRole кадрового контура."""
    db.add(PsmUserRole(user_id="user-1", role=PsmRole.PTO))
    db.flush()
    assert role_of(db, "user-1") is PsmRole.PTO
    assert role_of(db, "user-unknown") is None


def test_inactive_role_is_ignored(db):
    db.add(PsmUserRole(user_id="user-2", role=PsmRole.ADMIN, is_active=False))
    db.flush()
    assert role_of(db, "user-2") is None
