"""Нормализация. Каждый тест проверяет результат, а не равенство двух одинаково
испорченных значений — на этом однажды уже прошёл сломанный разбор дробей."""

from psm.matcher import norm, tokens, hard_tokens, domain_key


def test_latin_b_becomes_cyrillic():
    assert norm("Бетон B25") == norm("Бетон В25")


def test_decimal_survives():
    # 159х4,5 — это не 159х4. Потеря дробной части ломала ключ трубы.
    assert "4.5" in norm("труба 159х4,5")
    assert "4.5" in tokens("труба 159х4.5")


def test_multiplication_signs_unified():
    assert norm("530×5") == norm("530х5") == norm("530*5")


def test_gost_dropped():
    assert norm("Арматура 12 А500СЕ ГОСТ 34028-2016") == norm("Арматура 12 А500СЕ")


def test_hard_tokens_include_alphanumeric():
    # «МН117-6» не должен цепляться за «Провод РГКМ 6»
    assert "мн117" in hard_tokens(tokens("МН117-6"))


def test_concrete_key_order_independent():
    assert domain_key("Бетон В25 W8 F300") == domain_key("Бетон В25 F300 W8")


def test_concrete_w_not_confused_with_b():
    # В25 не должно распознаваться как W25
    assert domain_key("Бетон B25 F1 300 W8") == "BET|25|8|300"


def test_rebar_diameter_and_class_matter():
    assert domain_key("Арматура 12 А500СЕ") != domain_key("Арматура 16 А500СЕ")
    assert domain_key("Арматура 8 А500СЕ") != domain_key("Арматура 8 А240")


def test_pipe_key_keeps_wall_thickness():
    assert domain_key("Труба 159х4,5 С255") == "TRB|159|4.5"
