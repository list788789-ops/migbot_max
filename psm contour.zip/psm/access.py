"""
access.py — роли и права контура ПСМ.

Роли ПСМ живут в своей таблице, а не в UserRole кадрового контура. Причина простая:
кадровый модуль не должен знать про ПТО, а ПТО не должен получать доступ к персональным
данным просто потому, что его роль оказалась в общем перечислении. Связь с пользователем —
по идентификатору из сессии ТАКТ, без ForeignKey.

Проверки написаны по праву, а не по названию роли: require(user, Perm.CONFIRM_MATCH).
Пятая роль тогда не потребует правки ни одного роута.
"""

from __future__ import annotations

import enum
import os
import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, Enum, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from .core import PsmBase, _args


class PsmRole(str, enum.Enum):
    ADMIN = "admin"     # плюс загрузка НСИ, правка справочников, выгрузка в 1С
    PTO = "pto"         # чтение всего контура, подтверждение сопоставлений, отчёты


class Perm(str, enum.Enum):
    VIEW_CATALOGS = "view_catalogs"
    VIEW_REGISTER = "view_register"
    VIEW_REPORTS = "view_reports"
    CONFIRM_MATCH = "confirm_match"      # намеренно у ПТО: это его рабочий инструмент
    EDIT_OWN_ITEMS = "edit_own_items"    # позиции с origin = takt
    RUN_LOAD = "run_load"
    RUN_EXPORT = "run_export"
    MARK_DELETED = "mark_deleted"


ROLE_PERMS: dict[PsmRole, set[Perm]] = {
    PsmRole.PTO: {
        Perm.VIEW_CATALOGS, Perm.VIEW_REGISTER, Perm.VIEW_REPORTS, Perm.CONFIRM_MATCH,
    },
    PsmRole.ADMIN: {
        Perm.VIEW_CATALOGS, Perm.VIEW_REGISTER, Perm.VIEW_REPORTS, Perm.CONFIRM_MATCH,
        Perm.EDIT_OWN_ITEMS, Perm.RUN_LOAD, Perm.RUN_EXPORT, Perm.MARK_DELETED,
    },
}


class PsmUserRole(PsmBase):
    """Роль пользователя ТАКТ в контуре ПСМ.

    user_id — идентификатор из сессии ТАКТ. ForeignKey намеренно нет: удаление или
    миграция кадровых таблиц не должны трогать контур.
    """
    __tablename__ = "psm_user_role"
    __table_args__ = _args(UniqueConstraint("user_id", name="uq_psm_user_role"))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id: Mapped[str] = mapped_column(String(36), index=True)
    role: Mapped[PsmRole] = mapped_column(Enum(PsmRole), index=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    granted_by_user_id: Mapped[str | None] = mapped_column(String(36))
    granted_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class AccessDenied(Exception):
    """Отдельный тип, чтобы веб-слой отдал 403, а тесты ловили именно его."""


def role_of(db, user_id: str) -> PsmRole | None:
    if not user_id:
        return None
    row = (db.query(PsmUserRole)
             .filter(PsmUserRole.user_id == user_id, PsmUserRole.is_active.is_(True))
             .one_or_none())
    return row.role if row else None


def perms_of(role: PsmRole | None) -> set[Perm]:
    return ROLE_PERMS.get(role, set())


def can(role: PsmRole | None, perm: Perm) -> bool:
    return perm in perms_of(role)


def require(role: PsmRole | None, perm: Perm) -> None:
    """Единственная точка проверки. Роуты вызывают её, а не сравнивают строки."""
    if role is None:
        raise AccessDenied("Роль в контуре ПСМ не назначена")
    if not can(role, perm):
        raise AccessDenied(f"Роль {role.value} не имеет права {perm.value}")
