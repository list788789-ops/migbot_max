"""
psm_core.py — ядро справочников контура ПСМ внутри ТАКТ.

Порядок работ, из которого следует эта структура:
    структура → загрузка в ТАКТ → наполнение → выгрузка в 1С.
Выгрузка последняя, поэтому здесь она присутствует только как состояние записи,
а не как логика. Логика выгрузки пишется отдельным модулем и на ядро не влияет.

Три решения, определяющие всё остальное:

1. ТАКТ первичен. Ключ записи — собственный uuid, а не код заказчика. Код заказчика
   (external_code) — атрибут, по которому идёт сопоставление при выгрузке. Позиции,
   которых в справочнике заказчика нет — труба 478х5, МН117-6, рамы ДБ1 и ДБ2 —
   заводятся с пустым кодом и признаком needs_code; в 1С они не уходят, пока код
   не появится.

2. Единицы измерения — отдельный справочник, а не строка в каждой таблице. Хранят
   базовую единицу и коэффициент: тонна ссылается на килограмм с коэффициентом 1000.
   Пересчёт кг/т идёт только через него. Единица стоит на характеристике, а не на
   номенклатуре: сегодня конфликтов в данных нет, но это свойство текущей выгрузки,
   а не правило. Поднять единицу на номенклатуру нужно в момент выгрузки в 1С,
   с проверкой: у номенклатуры больше одной единицы — позиция в выгрузку не идёт.

3. Пометка удаления обязательна. Раз запись рождается у нас и уже могла уйти в 1С,
   удалять её нельзя — на неё ссылаются выгруженные строки. Пометить — единственный
   способ сказать «больше не использовать».
"""

from __future__ import annotations

import enum
import os
import uuid
from datetime import datetime

from sqlalchemy import (
    Boolean, DateTime, Enum, ForeignKey, Index, Integer, Numeric, String, Text, UniqueConstraint
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

PSM_SCHEMA = os.getenv("PSM_SCHEMA", "psm")
_IS_PG = (os.getenv("DATABASE_URL", "")).startswith(("postgres", "postgresql"))
_S = {"schema": PSM_SCHEMA} if _IS_PG else {}


class PsmBase(DeclarativeBase):
    """Отдельная метадата. create_all кадрового контура ТАКТ эти таблицы не видит."""


def _uuid() -> str:
    return str(uuid.uuid4())


def _fk(t: str) -> str:
    return f"{PSM_SCHEMA}.{t}" if _IS_PG else t


def _args(*constraints):
    return (*constraints, _S) if _IS_PG else (constraints or ())


# ============================ ПЕРЕЧИСЛЕНИЯ ============================

class Origin(str, enum.Enum):
    """Откуда взялась запись. Определяет, кто имеет право её менять."""
    CUSTOMER = "customer"   # пришла из справочника заказчика, мы не правим
    TAKT = "takt"           # заведена у нас, мы владельцы


class ExportState(str, enum.Enum):
    """Состояние выгрузки в 1С. Позволяет отдавать только изменения, а не 141 776 строк."""
    NOT_EXPORTED = "not_exported"
    EXPORTED = "exported"
    MODIFIED = "modified"       # изменена после выгрузки
    BLOCKED = "blocked"         # выгрузка невозможна: нет кода или конфликт единиц


# ============================ ОБЩАЯ ЧАСТЬ ============================

class CatalogMixin:
    """Общая часть справочника.

    external_code — код заказчика. Не первичный ключ и не обязателен: позиции,
    которых у заказчика нет, живут с пустым кодом и needs_code = True.
    """
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    name: Mapped[str] = mapped_column(String(250), index=True)
    external_code: Mapped[str | None] = mapped_column(String(20), index=True)
    needs_code: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    origin: Mapped[Origin] = mapped_column(Enum(Origin), default=Origin.CUSTOMER, index=True)
    deletion_mark: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    predefined: Mapped[bool] = mapped_column(Boolean, default=False)
    export_state: Mapped[ExportState] = mapped_column(
        Enum(ExportState), default=ExportState.NOT_EXPORTED, index=True)
    exported_at: Mapped[datetime | None] = mapped_column(DateTime)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime | None] = mapped_column(DateTime, onupdate=datetime.utcnow)

    def touch(self) -> None:
        """Любое изменение выгруженной записи переводит её в состояние MODIFIED."""
        if self.export_state == ExportState.EXPORTED:
            self.export_state = ExportState.MODIFIED


# ============================ ЕДИНИЦЫ ИЗМЕРЕНИЯ ============================

class Uom(CatalogMixin, PsmBase):
    """Единица измерения. Отдельный справочник, а не строка в каждой таблице.

    base_id и factor задают пересчёт: т → кг с коэффициентом 1000. Ручной пересчёт
    запрещён — именно на нём расходятся ВОР (кг по ТЗ) и справочник МТР (т).
    Синонимы «шт.», «тн», «к-т», «м³» не заводятся отдельными записями: они живут
    в UomAlias и разворачиваются загрузчиком на входе.
    """
    __tablename__ = "psm_uom"
    __table_args__ = _args(UniqueConstraint("code", name="uq_psm_uom_code"))
    code: Mapped[str] = mapped_column(String(10), index=True)
    okei: Mapped[str | None] = mapped_column(String(3), index=True)
    base_id: Mapped[str | None] = mapped_column(ForeignKey(_fk("psm_uom.id")))
    factor: Mapped[float] = mapped_column(Numeric(18, 6), default=1)
    base = relationship("Uom", remote_side="Uom.id")

    def to_base(self, qty: float) -> float:
        return float(qty) * float(self.factor)


class UomAlias(PsmBase):
    """Написания единиц из источников: «шт.», «шт. », «тн», «к-т», «м³», «п.м./шт».

    Отдельной таблицей, чтобы новое написание добавлялось данными, а не правкой кода.
    """
    __tablename__ = "psm_uom_alias"
    __table_args__ = _args(UniqueConstraint("alias", name="uq_psm_uom_alias"))
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    alias: Mapped[str] = mapped_column(String(30), index=True)
    uom_id: Mapped[str] = mapped_column(ForeignKey(_fk("psm_uom.id")), index=True)
    source: Mapped[str | None] = mapped_column(String(30))     # свк | приложение3 | вор
    uom = relationship("Uom")


# ============================ НОМЕНКЛАТУРА ============================

class Nomenclature(CatalogMixin, PsmBase):
    """Номенклатура МТР. Иерархия групп и элементов.

    Единицы измерения здесь намеренно нет: она живёт на характеристике. При выгрузке
    в 1С единица поднимается сюда с проверкой на конфликт.
    """
    __tablename__ = "psm_nomenclature"
    __table_args__ = _args()
    parent_id: Mapped[str | None] = mapped_column(ForeignKey(_fk("psm_nomenclature.id")), index=True)
    is_folder: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    mtr_group_id: Mapped[str | None] = mapped_column(ForeignKey(_fk("psm_mtr_group.id")), index=True)
    parent = relationship("Nomenclature", remote_side="Nomenclature.id")
    characteristics = relationship("Characteristic", back_populates="owner")


class Characteristic(CatalogMixin, PsmBase):
    """Характеристика номенклатуры — рабочий ключ сопоставления ВОР, ЛРВ и регистра ПСМ.

    Владелец — номенклатура. Код заказчика уникален в пределах владельца, как в 1С.
    """
    __tablename__ = "psm_characteristic"
    __table_args__ = _args(
        UniqueConstraint("owner_id", "external_code", name="uq_psm_char_code"),
        Index("ix_psm_char_owner_name", "owner_id", "name"),
    )
    name: Mapped[str] = mapped_column(Text)
    owner_id: Mapped[str] = mapped_column(ForeignKey(_fk("psm_nomenclature.id")), index=True)
    uom_id: Mapped[str | None] = mapped_column(ForeignKey(_fk("psm_uom.id")), index=True)
    norm_name: Mapped[str | None] = mapped_column(String(500), index=True)   # для сопоставителя
    owner = relationship("Nomenclature", back_populates="characteristics")
    uom = relationship("Uom")


class MtrGroup(CatalogMixin, PsmBase):
    """Группа и тип МТР по ресурсной ведомости. Иерархия одним уровнем."""
    __tablename__ = "psm_mtr_group"
    __table_args__ = _args()
    parent_id: Mapped[str | None] = mapped_column(ForeignKey(_fk("psm_mtr_group.id")), index=True)
    is_folder: Mapped[bool] = mapped_column(Boolean, default=False)
    responsible: Mapped[str | None] = mapped_column(String(100))
    parent = relationship("MtrGroup", remote_side="MtrGroup.id")


# ============================ СЛУЖЕБНОЕ ЯДРА ============================

class LoadRun(PsmBase):
    """Прогон загрузки. Регистратор: любая запись знает, каким прогоном создана."""
    __tablename__ = "psm_load_run"
    __table_args__ = _args()
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    started_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime)
    source_file: Mapped[str | None] = mapped_column(String(250))
    source_hash: Mapped[str | None] = mapped_column(String(64), index=True)
    stats_json: Mapped[str | None] = mapped_column(Text)
    issues_json: Mapped[str | None] = mapped_column(Text)
    started_by_user_id: Mapped[str | None] = mapped_column(String(36))   # ТАКТ, без ForeignKey


class ExportRun(PsmBase):
    """Прогон выгрузки в 1С. Пишется на последнем этапе, ядру нужен только как ссылка."""
    __tablename__ = "psm_export_run"
    __table_args__ = _args()
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    started_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    target: Mapped[str] = mapped_column(String(30), default="1c")
    scope: Mapped[str | None] = mapped_column(String(60))       # nomenclature | characteristic
    rows_total: Mapped[int | None] = mapped_column(Integer)
    rows_blocked: Mapped[int | None] = mapped_column(Integer)
    file_name: Mapped[str | None] = mapped_column(String(250))
    started_by_user_id: Mapped[str | None] = mapped_column(String(36))   # ТАКТ, без ForeignKey


PREDEFINED_UOMS = [
    # код, наименование, ОКЕИ, базовая, коэффициент
    ("шт", "штука", "796", "шт", 1),
    ("м", "метр", "006", "м", 1),
    ("м2", "квадратный метр", "055", "м2", 1),
    ("м3", "кубический метр", "113", "м3", 1),
    ("кг", "килограмм", "166", "кг", 1),
    ("т", "тонна", "168", "кг", 1000),
    ("компл", "комплект", "839", "компл", 1),
    ("л", "литр", "112", "л", 1),
    ("км", "километр", "008", "м", 1000),
    ("упак", "упаковка", "778", "упак", 1),
]

UOM_ALIASES = [
    ("шт.", "шт"), ("шт. ", "шт"), ("штук", "шт"), ("ед.", "шт"),
    ("компл.", "компл"), ("к-т", "компл"), ("комплект", "компл"),
    ("уп", "упак"), ("уп.", "упак"), ("упак.", "упак"),
    ("тн", "т"), ("м³", "м3"), ("м²", "м2"),
    ("м.", "м"), ("метр", "м"), ("п.м.", "м"), ("пм", "м"), ("пог. м", "м"), ("м.п.", "м"),
]
