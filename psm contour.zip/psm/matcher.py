"""
matcher.py — сопоставление наименований МТР с характеристиками НСИ.

Кандидат склеивается из наименования номенклатуры и текста характеристики. Раньше
сравнивалась только характеристика, и «Арматура 12 А500СЕ» не находила «12 А500СЕ,
ГОСТ 34028-2016», потому что слово «Арматура» живёт в номенклатуре-владельце.

Четыре ступени, каждая работает с остатком предыдущей:
  1. точное совпадение нормализованной строки;
  2. доменные разборщики — арматура, бетон, труба, лист. Ключ вида ARM|12|А500СЕ
     собирается независимо от порядка слов и ссылок на ГОСТ;
  3. токенный скор, взвешенный по IDF, с обязательным совпадением жёстких токенов;
  4. остаток уходит оператору на подтверждение готового кандидата, а не на ручной поиск.

Два правила, без которых точность падает до 56% (проверено золотой выборкой):
  - доменный ключ, ведущий на несколько кандидатов, НЕ сопоставляется автоматически:
    ARM|6|А240 находит и «Арматура 6 А240», и «Сетка арматурная сварная Ф6 А240 100х100»;
  - нормализация обязана сохранять дробную часть: 159х4,5 — это не 159х4.
"""

from __future__ import annotations

import math
import re
from collections import Counter, defaultdict

AUTO = 0.72
REVIEW = 0.45

_HOMO = str.maketrans("ABEKMHOPCTYXaeopcyx", "АВЕКМНОРСТУХаеорсух")
_DROP = re.compile(r"\b(гост|ту|сп|снип|серия)\b[\s\-]*[\d.\-–/]*", re.I)
_KEEP_DEC = re.compile(r"(?<=\d)[.,](?=\d)")
_PUNCT = re.compile(r"[^0-9a-zа-я\u00b7]+", re.I)


def norm(s: str) -> str:
    """Нормализация. Точка между цифрами превращается в «·», чтобы уцелеть при чистке."""
    s = str(s or "").lower().replace("ё", "е").translate(_HOMO)
    s = s.replace("×", "х").replace("*", "х")
    s = _DROP.sub(" ", s)
    s = _KEEP_DEC.sub("\u00b7", s)
    s = _PUNCT.sub(" ", s)
    return s.replace("\u00b7", ".").strip()


def tokens(s: str) -> list[str]:
    return [t for t in norm(s).split() if len(t) > 1 or t.isdigit()]


_NUM = re.compile(r"^\d+(\.\d+)?$")


def hard_tokens(ts) -> set[str]:
    """Числа и токены с цифрой. Обязаны совпасть целиком: иначе «МН117-6»
    цепляется за «Провод РГКМ 6»."""
    return {t for t in ts if _NUM.match(t) or any(c.isdigit() for c in t)}


_RE_BET = re.compile(r"бетон")
_RE_B = re.compile(r"\b[bв]\s?(\d{1,3})\b")          # латинская B после нормализации станет В
_RE_W = re.compile(r"\bw\s?(\d{1,2})\b")   # только латинская w: В25 иначе распознаётся как W25
_RE_F = re.compile(r"\bf\s?1?\s?(\d{2,4})\b")
_RE_ARM = re.compile(r"(?:^|\s)(?:ф|d|ø)?\s?(\d{1,2})\s*[\- ]?\s*(а\s?\d{3}\s?с?е?)")
_RE_DXS = re.compile(r"(\d{2,4})\s*х\s*(\d{1,3}(?:\.\d)?)")
_RE_LIST = re.compile(r"\bлист")


def domain_key(text: str) -> str | None:
    n = norm(text)
    if _RE_BET.search(n):
        b = _RE_B.search(n)
        if b:
            w = _RE_W.search(n)
            f = _RE_F.search(n)
            return f"BET|{b.group(1)}|{w.group(1) if w else '-'}|{f.group(1) if f else '-'}"
    if "арматур" in n:
        m = _RE_ARM.search(n)
        if m:
            return f"ARM|{int(m.group(1))}|{re.sub(r'\\s+', '', m.group(2)).upper()}"
    if "труб" in n:
        m = _RE_DXS.search(n)
        if m:
            return f"TRB|{m.group(1)}|{m.group(2)}"
    if _RE_LIST.search(n):
        m = re.search(r"(\d{1,2}(?:\.\d)?)\s*мм", n)
        if m:
            return f"LST|{m.group(1)}"
    return None


def genus(text: str) -> str:
    """Родовое слово: первое значимое существительное. Используется как тай-брейк,
    когда доменный ключ ведёт на несколько кандидатов."""
    ts = tokens(text)
    return ts[0][:6] if ts else ""


class Matcher:
    def __init__(self, candidates):
        """candidates: (code, наименование номенклатуры, текст характеристики)."""
        self.codes, self.texts, self.toks, self.nums, self.genus = [], [], [], [], []
        self.exact: dict[str, str] = {}
        self.by_key: dict[str, list[int]] = defaultdict(list)
        self.index: dict[str, list[int]] = defaultdict(list)
        df: Counter[str] = Counter()
        for code, nom, ch in candidates:
            text = f"{nom} {ch}".strip()
            ts = tokens(text)
            i = len(self.codes)
            self.codes.append(code); self.texts.append(text)
            self.toks.append(set(ts)); self.nums.append(hard_tokens(ts))
            self.genus.append(genus(nom))
            self.exact.setdefault(norm(text), code)
            k = domain_key(text)
            if k:
                self.by_key[k].append(i)
            for t in set(ts):
                df[t] += 1
                self.index[t].append(i)
        n = max(len(self.codes), 1)
        self.idf = {t: math.log(n / (1 + c)) for t, c in df.items()}
        self.stop = {t for t, c in df.items() if c > n * 0.25}

    def match(self, query: str):
        """(код характеристики или None, скор, способ). Способы: exact, domain,
        token — автоматически; review — на подтверждение; none — кандидатов нет."""
        q = norm(query)
        if not q:
            return None, 0.0, "empty"
        if q in self.exact:
            return self.exact[q], 1.0, "exact"

        k = domain_key(query)
        if k and k in self.by_key:
            pool = self.by_key[k]
            if len(pool) == 1:
                return self.codes[pool[0]], 0.97, "domain"
            g = genus(query)
            same = [i for i in pool if self.genus[i] == g]
            if len(same) == 1:
                return self.codes[same[0]], 0.95, "domain"
            return self.codes[pool[0]], 0.60, "review"      # неоднозначно — оператору

        qt = tokens(query)
        qs, qn = set(qt), hard_tokens(qt)
        probe = sorted((t for t in qs if t not in self.stop),
                       key=lambda t: -self.idf.get(t, 0))[:6]
        if not probe:
            return None, 0.0, "none"
        cand: Counter[int] = Counter()
        for t in probe:
            for i in self.index.get(t, ())[:4000]:
                cand[i] += 1
        if not cand:
            return None, 0.0, "none"
        qw = sum(self.idf.get(t, 0) for t in qs) or 1.0
        best_i, best = -1, 0.0
        for i, _ in cand.most_common(400):
            if qn and not qn.issubset(self.nums[i]):
                continue
            inter = qs & self.toks[i]
            if not inter:
                continue
            w = sum(self.idf.get(t, 0) for t in inter)
            score = w / qw * (len(inter) / max(len(qs | self.toks[i]), 1)) ** 0.25
            if score > best:
                best, best_i = score, i
        if best_i < 0:
            return None, 0.0, "none"
        if best >= AUTO:
            return self.codes[best_i], best, "token"
        if best >= REVIEW:
            return self.codes[best_i], best, "review"
        return None, best, "none"
