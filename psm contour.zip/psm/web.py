"""
web.py — сервис контура ПСМ на поддомене psm.infolay.

Отдельный сервис в том же Railway-проекте, что bot.py и webforms.py: тот же репозиторий,
тот же DATABASE_URL, свой Start Command и свой домен.

    Start Command: uvicorn psm.web:app --host 0.0.0.0 --port $PORT
    Custom Domain: psm.infolay.ru

Аутентификация переиспользуется: тот же SessionMiddleware с тем же SESSION_SECRET читает
ту же cookie, что и ТАКТ. Свой логин не заводим — иначе появится второй контур
пользователей, который придётся синхронизировать.

Роль в контуре берётся из psm_user_role, а не из UserRole кадрового модуля: ПТО не должен
получать доступ к персональным данным просто потому, что его роль попала в общее
перечисление. Контур только читает идентификатор пользователя и никогда не пишет
в кадровые таблицы.
"""

from __future__ import annotations

import os

from fastapi import Depends, FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import Session, sessionmaker
from starlette.middleware.sessions import SessionMiddleware

from .access import AccessDenied, Perm, PsmRole, require, role_of
from .core import (
    Characteristic, LoadRun, MtrGroup, Nomenclature, PsmBase, Uom, UomAlias,
)

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///psm.db")
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql://", 1)

engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False)

app = FastAPI(title="ПСМ — сметы и комплектация")
app.add_middleware(SessionMiddleware, secret_key=os.getenv("SESSION_SECRET", "dev"))

ORG_NAME = os.getenv("ORG_NAME", "ООО «ИНФОЛАЙ»")
TAKT_URL = os.getenv("TAKT_URL", "https://takt.infolay.ru/")


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def current(request: Request, db: Session) -> tuple[str | None, PsmRole | None]:
    uid = request.session.get("user_id")
    return uid, role_of(db, uid) if uid else None


@app.exception_handler(AccessDenied)
def _denied(request: Request, exc: AccessDenied):
    if not request.session.get("user_id"):
        return RedirectResponse("/login", status_code=307)
    return JSONResponse({"error": str(exc)}, status_code=403,
                        media_type="application/json; charset=utf-8")


CATALOGS = [
    ("Единицы измерения", Uom), ("Синонимы единиц", UomAlias),
    ("Группы и типы МТР", MtrGroup), ("Номенклатура", Nomenclature),
    ("Характеристики", Characteristic),
]

HEAD = """<!doctype html><html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>{title} · ПСМ</title>
<style>
:root{{--accent:#4a90e2;--ink:#111214;--sub:#5b626b;--line:#e6e9ee;--bg:#f7f8fa}}
*{{box-sizing:border-box}}
body{{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 -apple-system,Segoe UI,Roboto,Arial,sans-serif}}
header{{background:#fff;border-bottom:1px solid var(--line);padding:14px 20px}}
.org{{font-size:12px;letter-spacing:.09em;text-transform:uppercase;color:var(--sub)}}
h1{{font:700 24px/1.2 Georgia,serif;margin:2px 0 0;letter-spacing:-.02em}}
nav{{background:#fff;border-bottom:1px solid var(--line);padding:0 20px;display:flex;gap:2px;overflow-x:auto}}
nav a{{padding:11px 14px;color:var(--sub);text-decoration:none;white-space:nowrap;border-bottom:2px solid transparent}}
nav a.active{{color:var(--accent);border-bottom-color:var(--accent);font-weight:600}}
main{{max-width:1080px;margin:0 auto;padding:20px}}
section{{background:#fff;border:1px solid var(--line);border-radius:12px;padding:18px 20px;margin-bottom:16px}}
table{{width:100%;border-collapse:collapse;font-size:13.5px}}
th{{text-align:left;color:var(--sub);font-size:12px;letter-spacing:.04em;text-transform:uppercase;
border-bottom:1px solid var(--line);padding:8px 10px}}
td{{border-bottom:1px solid #f0f2f5;padding:8px 10px}}
td.n{{text-align:right;font-variant-numeric:tabular-nums}}
.role{{float:right;font-size:12px;color:var(--sub)}}
</style></head><body>
<header><div class="org">{org}</div><h1>ПСМ — сметы и комплектация<span class="role">{role}</span></h1></header>"""


def render(title: str, body: str, active: str, role: PsmRole | None) -> str:
    tabs = [("summary", "/", "Сводка"), ("catalogs", "/catalogs", "Справочники")]
    if role and require_safe(role, Perm.RUN_LOAD):
        tabs.append(("load", "/load", "Загрузка"))
    nav = "".join(f'<a href="{h}"{" class=active" if k == active else ""}>{t}</a>'
                  for k, h, t in tabs)
    nav += f'<a href="{TAKT_URL}">← ТАКТ</a>'
    head = HEAD.format(title=title, org=ORG_NAME, role=role.value if role else "нет роли")
    return f"{head}<nav>{nav}</nav><main>{body}</main></body></html>"


def require_safe(role: PsmRole | None, perm: Perm) -> bool:
    try:
        require(role, perm)
        return True
    except AccessDenied:
        return False


@app.get("/", response_class=HTMLResponse)
def summary(request: Request, db: Session = Depends(get_db)):
    _, role = current(request, db)
    require(role, Perm.VIEW_CATALOGS)
    rows = []
    for name, cls in CATALOGS:
        n = db.scalar(select(func.count()).select_from(cls)) or 0
        rows.append(f"<tr><td>{name}</td><td class='n'>{n:,}</td></tr>".replace(",", " "))
    last = db.scalar(select(LoadRun).order_by(LoadRun.started_at.desc()).limit(1))
    when = last.started_at.strftime("%d.%m.%Y %H:%M") if last else "не было"
    body = (f"<section><h2>Справочники</h2><table><thead><tr><th>Справочник</th>"
            f"<th class='n'>Записей</th></tr></thead><tbody>{''.join(rows)}</tbody></table>"
            f"<p style='color:#5b626b;font-size:13px'>Последняя загрузка: {when}</p></section>")
    return render("Сводка", body, "summary", role)


@app.get("/catalogs/{code}", response_class=HTMLResponse)
def nomenclature_card(code: str, request: Request, db: Session = Depends(get_db)):
    """Карточка номенклатуры с характеристиками и их единицами."""
    _, role = current(request, db)
    require(role, Perm.VIEW_CATALOGS)
    nom = db.scalar(select(Nomenclature).where(Nomenclature.external_code == code))
    if nom is None:
        return render("Не найдено", "<section>Номенклатура не найдена</section>", "catalogs", role)
    chars = db.scalars(select(Characteristic).where(Characteristic.owner_id == nom.id)
                       .order_by(Characteristic.name)).all()
    rows = "".join(
        f"<tr><td>{c.external_code or '—'}</td><td>{c.name}</td>"
        f"<td>{c.uom.code if c.uom else '—'}</td>"
        f"<td>{'требует кода' if c.needs_code else ''}</td></tr>" for c in chars)
    body = (f"<section><h2>{nom.name}</h2><p style='color:#5b626b'>код {nom.external_code}</p>"
            f"<table><thead><tr><th>Код</th><th>Характеристика</th><th>Ед.</th><th></th></tr>"
            f"</thead><tbody>{rows}</tbody></table></section>")
    return render(nom.name, body, "catalogs", role)


@app.post("/load")
def run_load(request: Request, db: Session = Depends(get_db)):
    """Перезагрузка НСИ. Только роль admin: ПТО справочники не грузит."""
    uid, role = current(request, db)
    require(role, Perm.RUN_LOAD)
    from . import loader

    base = os.getenv("PSM_SOURCE_DIR", "./source")
    run = loader.start_run(db, source_file=base, user_id=uid)
    rep = loader.Report(run)
    loader.load_uoms(db, rep)
    loader.load_mtr_groups(db, f"{base}/СВК ПСМ.xlsx", rep)
    loader.load_nomenclature(db, f"{base}/Приложение 3 Номенклатура МТР.xlsx", rep)
    rep.to_run()
    db.commit()
    return RedirectResponse("/", status_code=303)


@app.on_event("startup")
def _startup():
    """Таблицы создаются только своей метадатой — кадровые не затрагиваются."""
    PsmBase.metadata.create_all(engine)
